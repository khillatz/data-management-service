class Base:
    def __init__(self, name, size, description, communication_interface, _type):
        self.name = name
        self.size = size
        self.description = description
        self.communication_interface = communication_interface
        self.Type = _type
        self.properties = []


class Structure(Base):

    def __init__(self, name, size, description, communication_interface, _type, properties=None):
        super(Structure, self).__init__(name, size, description, communication_interface, _type)
        if properties is None:
            properties = []
        self.properties = properties
        self.elements = []

    def to_response(self):
        return {
            'name': self.name,
            'size': self.size,
            'description': self.description,
            'communication_interface': self.communication_interface,
            'elements': [x.to_response() for x in self.elements]
        }


class Element(Base):
    def __init__(self, name, size, description, communication_interface, parent, _type):
        super().__init__(name, size, description, communication_interface, _type)
        self.parent = parent

    def to_response(self):
        return {
            'name': self.name,
            'size': self.size,
            'description': self.description,
            'communication_interface': self.communication_interface,
            'properties': [x.to_response() for x in self.properties]
        }


class Property:
    def __init__(self, data_type, object_label, object_name, name_complete, description, length, size, _type, default_value):
        self.data_type = data_type
        self.object_label = object_label
        self.object_name = object_name
        self.name_complete = name_complete
        self.description = description
        self.length = length
        self.size = size
        self._type = _type
        self.default_value = default_value

    def to_response(self):
        return self.__dict__

