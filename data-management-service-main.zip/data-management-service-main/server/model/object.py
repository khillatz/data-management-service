from enum import Enum


class ObjectType(Enum):
    NONE = 'NONE'
    STRUCTURE = 'CFG_Structure'
    ARRAY = 'CFG_Array'
    STANDARD = 'CFG_Standard'
    ELEMENT = 'CFG_Element'


class ObjectLevel(Enum):
    ZER0 = 0
    ONE = 1
    TWO = 2


class Object:
    level = ObjectLevel.ZER0
    _type = ObjectType.NONE
