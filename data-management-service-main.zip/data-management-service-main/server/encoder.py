from __future__ import annotations

import json
from typing import Any
from flask.json import provider


class ResponseEncoder(json.JSONEncoder):
    def default(self, o: Any) -> Any:
        return o.__dict__


class ResponseJSONProvider(provider.JSONProvider):
    def dumps(self, obj: Any, **kwargs: Any) -> str:
        return json.dumps(obj, **kwargs, cls=ResponseEncoder)

    def loads(self, s: str | bytes, **kwargs):
        return json.loads(s, **kwargs)
