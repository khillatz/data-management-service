from flask import Flask, jsonify, request
import helper
import search
import encoder

app = Flask(__name__)
app.json_provider_class = encoder.ResponseJSONProvider
static_ic = helper.get_data('Static_IC')
dynamic_ic = helper.get_data('Dynamic_IC')


@app.route('/structure/<ic_type>')
def get_structure_list(ic_type):
    ic_data = static_ic if ic_type == 'static' else dynamic_ic
    print(ic_data)
    s = helper.generate_structures(ic_data)
    return jsonify(structures=[x.to_response() for x in s])


@app.route('/search/<any(static, dynamic):ic_type>')
def search_ic_type(ic_type):
    args = request.args
    object_name = args.get('object_name', default=None, type=str)
    prefix = args.get('prefix', default=None, type=str)
    communication_interface = args.get('communication_interface', default=None, type=str)
    data_type = args.get('data_type', default=None, type=str)

    s = helper.generate_structures(static_ic) if ic_type == 'static' else helper.generate_structures(dynamic_ic)
    results = search.search(
        s,
        name=object_name,
        prefix=prefix,
        communication_interface=communication_interface,
        data_type=data_type
    )
    return jsonify(structures=[x.to_response() for x in results])


@app.route('/create/<any(static, dynamic):ic_type>/<any(structure, element):data_type>', methods=['POST'])
def create_data(ic_type, data_type):
    print(f"Data creating {ic_type} & {data_type}")
    global static_ic
    global dynamic_ic

    if data_type == "structure":
        if ic_type == 'static':
            static_ic = helper.create_structure(request.get_json(), static_ic)
            helper.save_data(static_ic, ic_type)

        else:
            dynamic_ic = helper.create_structure(request.get_json(), dynamic_ic)
            helper.save_data(dynamic_ic, ic_type)

    else:
        if ic_type == 'static':
            static_ic = helper.create_element(request.get_json(), static_ic)
            helper.save_data(static_ic, ic_type)

        else:
            dynamic_ic = helper.create_element(request.get_json(), dynamic_ic)
            helper.save_data(dynamic_ic, ic_type)

    return jsonify(status="OK")


@app.route(
    '/delete/<any(static, dynamic):ic_type>/<any(structure, element):data_type>/<object_name>',
    methods=['DELETE']
)
def delete_data(ic_type, data_type, object_name):
    print(f"Deleting {ic_type} & {data_type} & {object_name}")
    global static_ic
    global dynamic_ic

    if data_type == "structure":
        if ic_type == 'static':
            static_ic = helper.delete_structure(object_name, static_ic)
            helper.save_data(static_ic, ic_type)

        else:
            dynamic_ic = helper.delete_structure(object_name, dynamic_ic)
            helper.save_data(dynamic_ic, ic_type)

    else:
        if ic_type == 'static':
            static_ic = helper.delete_element(object_name, static_ic)
            helper.save_data(static_ic, ic_type)

        else:
            dynamic_ic = helper.delete_element(object_name, dynamic_ic)
            helper.save_data(dynamic_ic, ic_type)

    return jsonify(status="OK")


if __name__ == '__main__':
    helper.delete_element('phfwConfig_IcPage_ConfigAreaUnInitBaseline', static_ic)
    print("Updated")
