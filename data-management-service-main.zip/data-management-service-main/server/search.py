import re


def search(data, name=None, prefix=None, communication_interface=None, data_type=None):
    results = []

    for d in data:
        if name:
            match = re.search(fr'.*{name}.*', d.name)
            if match:
                results.append(d)
                continue

        if communication_interface:
            match = re.search(fr'.*{communication_interface}.*', d.communication_interface)
            if match:
                results.append(d)
                continue

        for p in d.properties:
            if prefix:
                match = re.search(fr'.*{prefix}.*', p.object_label)
                if match:
                    results.append(d)
                    break

            if data_type:
                match = re.search(fr'.*{data_type}.*', p.data_type)
                if match:
                    results.append(d)
                    break

    return results
