from marshmallow import Schema, fields, EXCLUDE, validates, ValidationError


class StructureProperty(Schema):
    class Meta:
        unknown = EXCLUDE

    object_type = fields.Str(required=True)
    data_type = fields.Str(required=True)
    object_label = fields.Str(required=True)
    object_name = fields.Str(required=True)
    length = fields.Int(required=True)
    size = fields.Int(required=True)
    description = fields.Str(required=True)
    Type = fields.Str(required=True)
    entry_address = fields.Str(required=False, load_default="")
    communication_interface = fields.Str(required=True)
    default_value = fields.Str(required=True)


class CreateStructure(Schema):
    class Meta:
        unknown = EXCLUDE

    name = fields.Str(required=True)
    description = fields.Str(required=True)
    communication_interface = fields.Str(required=True)
    Type = fields.Str(required=True)
    properties = fields.List(fields.Nested(StructureProperty), required=True)

    # @validates("properties")
    # def validate_properties(self, value):
    #     if len(value) <= 0:
    #         raise ValidationError("Field properties cannot be empty")


class ElementProperty(Schema):
    class Meta:
        unknown = EXCLUDE

    object_name = fields.Str(required=True)
    default_value = fields.Str(required=False, load_default="")


class CreateElement(Schema):
    class Meta:
        unknown = EXCLUDE

    name = fields.Str(required=True)
    description = fields.Str(required=True)
    structure_name = fields.Str(required=True)
    properties = fields.List(fields.Nested(ElementProperty), required=True)
