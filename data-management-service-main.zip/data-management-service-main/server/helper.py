import math

import pandas as pd
from model import structure
from request import structure_request


file_path = './data/ElementIdentificationAdded copy.xlsx'
write_file_path = './data/ElementIdentificationAdded copy.xlsx'
column_names = [
    'ObjectType',
    'ParentStructure',
    'DataType',
    'ObjectLabel (prefix)',
    'ObjectLevel',
    'ObjectName',
    'Name complete',
    'Length',
    'Size',
    'Description',
    'SFR',
    'SFRAddress',
    'Type',
    'Entry address',
    'Comment',
    'Default Value',
    'Unnammed:1',
    'Unnammed:2',
    'Unnammed:3',
    'Unnammed:4',
    'Unnammed:5',
    'Unnammed:6',
    'Unnammed:7',
]


def is_structure(row):
    return row['ObjectType'] == 'CFG_Structure' and row['ObjectLevel'] == 1


def is_element(row):
    return row['ObjectType'] == 'CFG_Element' and row['ObjectLevel'] == 1


def is_property(row):
    return row['ObjectLevel'] == 2


def generate_structures(df):
    print("Generating structure")
    structures = []
    structure_continues = False
    element_continues = False

    current_structure = None
    current_element = None
    properties = []

    def end_element(current, props):
        current.properties = props
        for s in structures:
            if s.name == current_element.parent:
                s.elements.append(current_element)
                break

    def end_structure(current, props):
        current.properties = props
        structures.append(current)

    for _, row in df.iterrows():
        if is_structure(row):
            print(f"Structure found {row['ObjectName']}")
            if element_continues:
                print("Element continues")
                end_element(current_element, properties)
                properties = []
                element_continues = False

            if not structure_continues:
                print("Structure continues")
                structure_continues = True

            else:
                print("Else continues")
                end_structure(current_structure, properties)
                properties = []

            current_structure = structure.Structure(
                row['ObjectName'],
                row['Size'],
                row['Description'],
                row['Comment'],
                row['Type']
            )

        elif is_element(row):
            if structure_continues:
                end_structure(current_structure, properties)
                properties = []
                structure_continues = False

            if not element_continues:
                element_continues = True
            else:
                end_element(current_element, properties)
                properties = []

            current_element = structure.Element(
                row['ObjectName'],
                row['Size'],
                row['Description'],
                row['Comment'],
                row['ParentStructure'],
                row['Type']
            )

        elif is_property(row):
            properties.append(
                structure.Property(
                    row['DataType'],
                    row['ObjectLabel (prefix)'],
                    row['ObjectName'],
                    row['Name complete'],
                    row['Description'],
                    int(row['Length']),
                    int(row['Size']),
                    row['Type'],
                    row['Default Value']
                )
            )

        # end of element
        else:
            if structure_continues:
                end_structure(current_structure, properties)
                properties = []
                structure_continues = False
            elif element_continues:
                print("Element continues")
                end_element(current_element, properties)
                properties = []
                element_continues = False

    return structures


def get_data(sheet_name):
    print("Loading database...")
    db = pd.read_excel(file_path, sheet_name=sheet_name, index_col=0, header=None, names=column_names)
    db = db.replace({math.nan: ''})
    print('Ok.')

    return db


def save_data(data, ic_type):
    sheet_name = 'Static_IC' if ic_type == 'static' else 'Dynamic_IC'
    print(f"Saving data to sheet {sheet_name}...")
    with pd.ExcelWriter(write_file_path, engine="openpyxl", mode="a", if_sheet_exists="replace") as writer:
        data.to_excel(writer, sheet_name=sheet_name, index=True)
    print("Data saved")


def create_structure(data, ic_data):
    schema = structure_request.CreateStructure()
    data = schema.load(data)

    properties = []
    for prop in data.get("properties", []):
        properties.append(
            structure.Property(
                prop.get("data_type"),
                prop.get("object_label"),
                prop.get("object_name"),
                prop.get("object_name"),
                prop.get("description"),
                prop.get("length"),
                prop.get("size"),
                prop.get("Type"),
                prop.get("default_value")
            )
        )

    s = structure.Structure(
        data.get("name"),
        data.get("size"),
        data.get("description"),
        data.get("communication_interface"),
        data.get("Type"),
        properties
    )

    s_row = pd.Series({
        'ObjectType': 'CFG_Structure',
        'ObjectName': s.name,
        'ObjectLevel': 1,
        'Size': s.size,
        'Description': s.description,
        'Type': s.Type,
        'Comment': s.communication_interface

    })
    # remove last row
    last_row = ic_data.tail(1)
    ic_data.drop(ic_data.tail(1).index, inplace=True)
    ic_data = pd.concat([ic_data, s_row.to_frame().T], ignore_index=True)
    for prop in s.properties:
        p_row = pd.Series({
            'ObjectType': prop.data_type,
            'DataType': prop.data_type,
            'ObjectLabel (prefix)': prop.object_label,
            'ObjectLevel': 2,
            'ObjectName': prop.object_name,
            'Length': prop.length,
            'Size': prop.size
        })
        ic_data = pd.concat([ic_data, p_row.to_frame().T], ignore_index=True)

    # add end of table to the last row
    ic_data = pd.concat([ic_data, last_row], ignore_index=True)
    return ic_data


def create_element(data, ic_data):
    # convert data to schema
    schema = structure_request.CreateElement()
    data = schema.load(data)

    structs = generate_structures(ic_data)
    parent_struct = None
    element = None

    # search class by exact name
    for s in structs:
        if s.name == data.get("structure_name"):
            element = structure.Element(
                data.get("name"),
                s.size,
                data.get("description"),
                s.communication_interface,
                s,
                s.Type
            )

            element.properties = s.properties
            parent_struct = s
            break

    # create a new element for the class
    # add element at the end of the file
    e_row = pd.Series({
        'ObjectType': 'CFG_Element',
        'ParentStructure': parent_struct.name,
        'ObjectName': element.name,
        'ObjectLevel': 1,
        'Size': element.size,
        'Description': element.description,
        'Type': element.Type,
        'Comment': element.communication_interface
    })

    last_row = ic_data.tail(1)
    ic_data.drop(ic_data.tail(1).index, inplace=True)
    ic_data = pd.concat([ic_data, e_row.to_frame().T], ignore_index=True)

    for p in data.get("properties", []):
        for ep in element.properties:
            if ep.object_name == p["object_name"]:
                ep.default_value = p["default_value"]
                break

    # and save it
    for prop in element.properties:
        p_row = pd.Series({
            'ObjectType': prop.data_type,
            'DataType': prop.data_type,
            'ObjectLabel (prefix)': prop.object_label,
            'ObjectLevel': 2,
            'ObjectName': prop.object_name,
            'Name complete': prop.name_complete,
            'Length': prop.length,
            'Size': prop.size,
            'Description': prop.description,
            'Type': prop._type,
            'Default Value': prop.default_value
        })
        ic_data = pd.concat([ic_data, p_row.to_frame().T], ignore_index=True)

    # add end of table to the last row
    ic_data = pd.concat([ic_data, last_row], ignore_index=True)
    return ic_data


def delete_structure(object_name, ic_data):
    structure_start = -1
    structure_end = -1
    structure_continues = False
    for idx, row in ic_data.iterrows():
        if is_structure(row) and row['ObjectName'] == object_name:
            if not structure_continues:
                structure_start = int(idx)
                structure_continues = True
                continue

        elif (is_structure(row) or is_element(row)) and structure_continues:
            structure_continues = False
            structure_end = int(idx)

    ic_data = ic_data.drop([x for x in range(structure_start, structure_end)])
    return ic_data


def delete_element(object_name, ic_data):
    element_start = -1
    element_end = -1
    element_continues = False
    for idx, row in ic_data.iterrows():
        if is_element(row) and row['ObjectName'] == object_name:
            if not element_continues:
                element_start = int(idx)
                element_continues = True
                continue

        elif (is_element(row) or is_structure(row)) and element_continues:
            element_continues = False
            element_end = int(idx)

    ic_data = ic_data.drop([x for x in range(element_start, element_end)])
    return ic_data
